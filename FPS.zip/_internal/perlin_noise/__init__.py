"""Perlin noise generator library."""

from perlin_noise.perlin_noise import PerlinNoise

__all__ = [  # noqa: WPS410
    "PerlinNoise",
]
